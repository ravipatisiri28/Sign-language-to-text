@echo off
python src\train_model.py
pause

Put collected .npy landmark samples here.
Example:
data/A/0000.npy
data/A/0001.npy
...
data/B/0000.npy
...
Run src/collect_data.py to create them automatically.

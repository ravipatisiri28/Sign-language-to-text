The application creates the visual sign card at runtime.
You can later replace these cards with real A-Z sign-language images from a dataset
that matches the sign language standard you are using (for example ISL or ASL).
Do not assume ASL and ISL gestures are identical.

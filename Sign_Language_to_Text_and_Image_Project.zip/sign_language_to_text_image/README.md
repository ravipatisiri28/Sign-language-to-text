# Sign Language to Text & Image

A beginner-friendly real-time sign-language recognition project using:
- Python
- OpenCV (webcam)
- MediaPipe Hands (21 hand landmarks)
- TensorFlow/Keras (small neural network)
- Tkinter-style OpenCV UI
- Text + corresponding visual image card

## Important
This project is designed for you to collect your own sign samples and train the model.
It starts with A-Z labels. The recognizer works after training.

## Folder structure
```
sign_language_to_text_image/
├── src/
│   ├── collect_data.py
│   ├── train_model.py
│   └── recognize.py
├── data/
├── models/
├── images/
├── requirements.txt
└── README.md
```

## 1. Install
Open VS Code terminal inside this folder:
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 2. Collect data
```bash
python src/collect_data.py
```
Choose a letter, show that sign clearly to the camera, and press SPACE to save samples.
Press Q to stop.

Collect at least 100 samples per letter you want to recognize.
For a first test, train only A, B, C by editing `LABELS` in `src/collect_data.py` and `src/train_model.py`.

## 3. Train
```bash
python src/train_model.py
```

## 4. Run real-time recognition
```bash
python src/recognize.py
```
The webcam window displays:
- predicted sign
- confidence
- text sentence
- a visual card for the recognized letter

Keys:
- SPACE = add predicted letter to text
- BACKSPACE = delete last character
- C = clear sentence
- Q = quit

## Notes
This is a project framework, not a pretrained commercial translator. Accuracy depends on your dataset, lighting, camera position and sign-language standard. For Indian Sign Language, collect labels and examples specifically from ISL rather than assuming ASL signs are identical.

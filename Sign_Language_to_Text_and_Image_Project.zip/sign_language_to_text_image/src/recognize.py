import cv2
import mediapipe as mp
import numpy as np
import tensorflow as tf
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
MODEL = BASE / "models" / "sign_model.keras"
LABELS_FILE = BASE / "models" / "labels.npy"

if not MODEL.exists() or not LABELS_FILE.exists():
    raise SystemExit("Model not found. Run collect_data.py and then train_model.py first.")

model = tf.keras.models.load_model(MODEL)
labels = np.load(LABELS_FILE, allow_pickle=True).tolist()

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils

def extract_landmarks(hand_landmarks):
    pts = np.array([[p.x, p.y, p.z] for p in hand_landmarks.landmark], dtype=np.float32)
    pts = pts - pts[0]
    scale = np.max(np.linalg.norm(pts[:, :2], axis=1))
    if scale > 1e-6:
        pts = pts / scale
    return pts.flatten()

def make_card(letter, confidence):
    card = np.ones((210, 210, 3), dtype=np.uint8) * 245
    cv2.rectangle(card, (5,5), (205,205), (40,40,40), 3)
    cv2.putText(card, letter, (65,130), cv2.FONT_HERSHEY_SIMPLEX, 3.5, (30,30,30), 7)
    cv2.putText(card, f"{confidence*100:.1f}%", (55,180),
                cv2.FONT_HERSHEY_SIMPLEX, 0.65, (70,70,70), 2)
    return card

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    raise SystemExit("Camera could not be opened.")

sentence = ""
last_pred = ""
stable_count = 0

with mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=1,
    min_detection_confidence=0.6,
    min_tracking_confidence=0.6
) as hands:

    while True:
        ok, frame = cap.read()
        if not ok:
            break

        frame = cv2.flip(frame, 1)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        result = hands.process(rgb)

        pred = "-"
        conf = 0.0

        if result.multi_hand_landmarks:
            hand = result.multi_hand_landmarks[0]
            mp_draw.draw_landmarks(frame, hand, mp_hands.HAND_CONNECTIONS)
            x = extract_landmarks(hand)
            probs = model.predict(x.reshape(1, -1), verbose=0)[0]
            i = int(np.argmax(probs))
            pred = labels[i]
            conf = float(probs[i])

            if pred == last_pred:
                stable_count += 1
            else:
                stable_count = 0
                last_pred = pred

        cv2.putText(frame, f"Sign: {pred}   Confidence: {conf*100:.1f}%",
                    (10,35), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0,255,0), 2)
        cv2.putText(frame, f"Text: {sentence}",
                    (10,75), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255,255,255), 2)
        cv2.putText(frame, "SPACE=add sign | BACKSPACE=delete | C=clear | Q=quit",
                    (10,110), cv2.FONT_HERSHEY_SIMPLEX, 0.52, (255,255,255), 2)

        card = make_card(pred if pred != "-" else "?", conf)
        h = min(frame.shape[0], card.shape[0])
        w = min(frame.shape[1], card.shape[1])
        frame[10:10+h, frame.shape[1]-w-10:frame.shape[1]-10] = card

        cv2.imshow("Sign Language -> Text + Image", frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        elif key == 32 and pred != "-" and conf >= 0.60:
            sentence += pred
        elif key in (8, 127):
            sentence = sentence[:-1]
        elif key == ord('c'):
            sentence = ""

cap.release()
cv2.destroyAllWindows()

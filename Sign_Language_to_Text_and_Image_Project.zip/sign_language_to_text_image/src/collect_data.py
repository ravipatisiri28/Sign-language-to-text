import cv2
import mediapipe as mp
import numpy as np
from pathlib import Path

LABELS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
SAMPLES_PER_LABEL = 100
DATA_DIR = Path(__file__).resolve().parent.parent / "data"

mp_hands = mp.solutions.hands
mp_draw = mp.solutions.drawing_utils

def extract_landmarks(hand_landmarks):
    # Normalize landmarks relative to wrist, then scale by max distance.
    pts = np.array([[p.x, p.y, p.z] for p in hand_landmarks.landmark], dtype=np.float32)
    pts = pts - pts[0]
    scale = np.max(np.linalg.norm(pts[:, :2], axis=1))
    if scale > 1e-6:
        pts = pts / scale
    return pts.flatten()

def main():
    print("Available labels:", ", ".join(LABELS))
    label = input("Enter one label (A-Z): ").strip().upper()
    if label not in LABELS:
        print("Invalid label.")
        return

    out = DATA_DIR / label
    out.mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Camera could not be opened.")
        return

    print("Show the sign. Press SPACE to save a sample. Press Q to quit.")
    saved = len(list(out.glob("*.npy")))

    with mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        min_detection_confidence=0.6,
        min_tracking_confidence=0.6
    ) as hands:
        while saved < SAMPLES_PER_LABEL:
            ok, frame = cap.read()
            if not ok:
                break
            frame = cv2.flip(frame, 1)
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            result = hands.process(rgb)

            if result.multi_hand_landmarks:
                hand = result.multi_hand_landmarks[0]
                mp_draw.draw_landmarks(frame, hand, mp_hands.HAND_CONNECTIONS)

            cv2.putText(frame, f"Label: {label}  Saved: {saved}/{SAMPLES_PER_LABEL}",
                        (10, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)
            cv2.putText(frame, "SPACE=save   Q=quit",
                        (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,255), 2)
            cv2.imshow("Collect Sign Language Data", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            if key == 32 and result.multi_hand_landmarks:
                vec = extract_landmarks(result.multi_hand_landmarks[0])
                np.save(out / f"{saved:04d}.npy", vec)
                saved += 1

    cap.release()
    cv2.destroyAllWindows()
    print(f"Saved {saved} samples for {label}.")

if __name__ == "__main__":
    main()

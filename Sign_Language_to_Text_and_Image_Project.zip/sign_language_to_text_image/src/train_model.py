from pathlib import Path
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split

BASE = Path(__file__).resolve().parent.parent
DATA_DIR = BASE / "data"
MODEL_DIR = BASE / "models"
MODEL_DIR.mkdir(exist_ok=True)

LABELS = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")

X, y = [], []
for idx, label in enumerate(LABELS):
    folder = DATA_DIR / label
    if not folder.exists():
        continue
    for f in folder.glob("*.npy"):
        arr = np.load(f)
        if arr.shape == (63,):
            X.append(arr)
            y.append(idx)

if len(set(y)) < 2:
    raise SystemExit("Collect data for at least 2 labels before training.")

X = np.asarray(X, dtype=np.float32)
y = np.asarray(y, dtype=np.int32)

classes = sorted(set(y))
label_names = [LABELS[i] for i in classes]
mapping = {old: new for new, old in enumerate(classes)}
y2 = np.array([mapping[v] for v in y], dtype=np.int32)

X_train, X_test, y_train, y_test = train_test_split(
    X, y2, test_size=0.2, random_state=42, stratify=y2
)

model = models.Sequential([
    layers.Input(shape=(63,)),
    layers.Dense(128, activation="relu"),
    layers.Dropout(0.25),
    layers.Dense(64, activation="relu"),
    layers.Dropout(0.20),
    layers.Dense(len(label_names), activation="softmax")
])

model.compile(
    optimizer="adam",
    loss="sparse_categorical_crossentropy",
    metrics=["accuracy"]
)

model.fit(
    X_train, y_train,
    validation_split=0.15,
    epochs=25,
    batch_size=32,
    verbose=1
)

loss, acc = model.evaluate(X_test, y_test, verbose=0)
print(f"Test accuracy: {acc*100:.2f}%")

model.save(MODEL_DIR / "sign_model.keras")
np.save(MODEL_DIR / "labels.npy", np.array(label_names))
print("Saved model:", MODEL_DIR / "sign_model.keras")
print("Saved labels:", MODEL_DIR / "labels.npy")

@echo off
python src\collect_data.py
pause

@echo off
python src\recognize.py
pause
